require('bar')
require('b/baz')
